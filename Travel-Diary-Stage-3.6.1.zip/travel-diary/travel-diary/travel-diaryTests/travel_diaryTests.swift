//
//  travel_diaryTests.swift
//  travel-diaryTests
//
//  Created by Wilson Ho on 24/6/2025.
//

import Testing
@testable import travel_diary

struct travel_diaryTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
