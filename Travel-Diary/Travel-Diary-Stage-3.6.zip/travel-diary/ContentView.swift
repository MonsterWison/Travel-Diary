//
//  ContentView.swift
//  travel-diary
//
//  Created by Wilson Ho on 24/6/2025.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TravelMapView()
    }
}

#Preview {
    ContentView()
}
